//
//  TaskStepView.swift
//  Verifier_new
//
//  Created by Кирилл Ковыршин on 24/01/2019.
//  Copyright © 2019 Verifier. All rights reserved.
//

import UIKit


class TaskStepView: UIView {
    
    
    
    //MARK: - OUTLETS
    @IBOutlet weak var orderIdLabel: UILabel!
    @IBOutlet weak var orderName: UILabel!
    @IBOutlet weak var orderType: UILabel!
    @IBOutlet weak var orderStep: UILabel!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var stepInfoButton: UIButton!
    
    
    func localizationView() {
        
        
     
        
    }
    
}
